import './styles.css';

const positions = {
  'Centre-Back': {
    code: 'CB',
    descriptor: 'duel-ready defender',
    priority: 'first-step acceleration, aerial robustness & recovery runs',
    technical: 'receive across the body, break lines with clipped passes, defend the space behind',
    tactical: 'back-four spacing, rest-defence scanning, timing the step',
    strengths: ['Deceleration', 'Aerial power', 'Core stability']
  },
  'Central Midfielder': {
    code: 'CM',
    descriptor: 'high-output connector',
    priority: 'repeat sprint ability, scanning density & change of tempo',
    technical: 'open hips on the half-turn, play through pressure, arrive late into the box',
    tactical: 'third-man movement, counterpress triggers, cover shadow discipline',
    strengths: ['Repeat efforts', 'Scanning', 'Change of direction']
  },
  Winger: {
    code: 'WG',
    descriptor: '1v1 difference-maker',
    priority: 'multi-directional speed, elastic power & final-third sharpness',
    technical: 'attack the outside shoulder, disguise the cut-back, finish after separation',
    tactical: 'weak-side arrival, touchline occupation, counterpress on loss',
    strengths: ['Multi-directional speed', '1v1 separation', 'Finishing']
  },
  Striker: {
    code: 'ST',
    descriptor: 'box predator',
    priority: 'explosive separation, finishing under fatigue & repeat pressing',
    technical: 'protect the first touch, finish across the keeper, connect with bounce passes',
    tactical: 'pin the centre-back, curve the press, attack the blind-side channel',
    strengths: ['Explosive power', 'Finishing', 'Pressing']
  },
  Goalkeeper: {
    code: 'GK',
    descriptor: 'front-foot organiser',
    priority: 'lateral power, set position quality & distribution under pressure',
    technical: 'set early, secure the second action, clip the far-side outlet',
    tactical: 'manage depth, organise the line, recognise the counter window',
    strengths: ['Lateral power', 'Distribution', 'Reaction speed']
  }
};

const goalMeta = {
  'In-Season Maintenance': { tag: 'Maintain', tone: 'Protect output while keeping the nervous system fresh for matchday.' },
  'Pre-Season Conditioning': { tag: 'Build', tone: 'Layer repeatable intensity, tissue capacity and football volume without rushing adaptation.' },
  'Post-Season Recovery': { tag: 'Restore', tone: 'Downshift total load, restore range and reintroduce playful technical exposure.' },
  'Speed & Agility': { tag: 'Express', tone: 'Make every step cleaner: accelerate, brake, re-accelerate and own the first three metres.' },
  'Strength & Power': { tag: 'Produce', tone: 'Build force qualities that transfer to duels, take-offs, deceleration and finishing.' },
  'Injury Comeback': { tag: 'Rebuild', tone: 'Use progressive exposure, clean mechanics and honest monitoring to earn intensity back.' }
};

const baseDays = [
  { day: 'Day 1', short: 'MON', type: 'Build', color: 'lime' },
  { day: 'Day 2', short: 'TUE', type: 'Express', color: 'orange' },
  { day: 'Day 3', short: 'WED', type: 'Restore', color: 'sky' },
  { day: 'Day 4', short: 'THU', type: 'Sharp', color: 'pink' },
  { day: 'Day 5', short: 'FRI', type: 'Prime', color: 'lime' },
  { day: 'Day 6', short: 'SAT', type: 'Match', color: 'orange' },
  { day: 'Day 7', short: 'SUN', type: 'Reset', color: 'sky' }
];

const defaultForm = {
  position: 'Winger',
  fitness: 'Elite / Pro',
  goal: 'In-Season Maintenance',
  days: '5',
  matchday: 'Saturday',
  duration: '75',
  foot: 'Right',
  environment: 'Full gym + pitch',
  emphasis: 'Speed & agility'
};

let currentForm = { ...defaultForm };
let activeDay = 0;
let planVersion = 1;
let analyzerState = {
  baselineSprint: '1.82',
  latestSprint: '1.76',
  baselineRepeat: '4.62',
  latestRepeat: '4.48',
  baselineTechnical: '72',
  latestTechnical: '81',
  sessionsPlanned: '5',
  sessionsCompleted: '5',
  readiness: '8',
  soreness: '2'
};
let chatOpen = false;
let isListening = false;
let chatMessages = [
  { role: 'coach', text: 'I’m your PitchLab coach. Ask me about today’s session, recovery, fueling, or your progress score.' }
];

const icon = (name, size = 18) => {
  const icons = {
    arrow: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13M13 6l6 6-6 6"/></svg>`,
    chevron: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m8 10 4 4 4-4"/></svg>`,
    check: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>`,
    bolt: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z"/></svg>`,
    clock: `<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/></svg>`,
    activity: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h4l2-7 4 14 2-7h6"/></svg>`,
    drop: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3s6 6.2 6 11a6 6 0 0 1-12 0c0-4.8 6-11 6-11Z"/></svg>`,
    moon: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 15.5A8.5 8.5 0 0 1 8.5 4 8.6 8.6 0 1 0 20 15.5Z"/></svg>`,
    menu: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>`,
    close: `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 6 12 12M18 6 6 18"/></svg>`,
    mic: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M6 11a6 6 0 0 0 12 0M12 17v4M9 21h6"/></svg>`,
    grid: `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6" rx="1"/><rect x="14" y="4" width="6" height="6" rx="1"/><rect x="4" y="14" width="6" height="6" rx="1"/><rect x="14" y="14" width="6" height="6" rx="1"/></svg>`
  };
  return `<span class="icon icon-${name}" style="--icon-size:${size}px">${icons[name] || icons.activity}</span>`;
};

function h(tag, attrs = {}, children = '') {
  const attrString = Object.entries(attrs).map(([key, value]) => `${key}="${String(value).replaceAll('"', '&quot;')}"`).join(' ');
  return `<${tag}${attrString ? ` ${attrString}` : ''}>${children}</${tag}>`;
}

function selectField(id, label, value, options, note = '') {
  return `<label class="field" for="${id}"><span class="field-label">${label}</span><span class="select-wrap"><select id="${id}" data-field="${id}">${options.map(option => `<option ${option === value ? 'selected' : ''}>${option}</option>`).join('')}</select>${icon('chevron', 16)}</span>${note ? `<span class="field-note">${note}</span>` : ''}</label>`;
}

function resultField(id, label, value, suffix, step = '1') {
  return `<label class="result-field" for="${id}"><span class="field-label">${label}</span><span class="result-input"><input id="${id}" data-result="${id}" type="number" min="0" step="${step}" value="${value}" /><b>${suffix}</b></span></label>`;
}

function analyzeAthleteResults(results) {
  const values = Object.fromEntries(Object.entries(results).map(([key, value]) => [key, Number(value) || 0]));
  const speedDelta = values.baselineSprint ? ((values.baselineSprint - values.latestSprint) / values.baselineSprint) * 100 : 0;
  const repeatDelta = values.baselineRepeat ? ((values.baselineRepeat - values.latestRepeat) / values.baselineRepeat) * 100 : 0;
  const technicalDelta = values.baselineTechnical ? ((values.latestTechnical - values.baselineTechnical) / values.baselineTechnical) * 100 : 0;
  const adherence = values.sessionsPlanned ? (values.sessionsCompleted / values.sessionsPlanned) * 100 : 0;
  const readinessScore = (values.readiness / 10) * 100;
  const sorenessScore = Math.max(0, 100 - (values.soreness / 10) * 100);
  const overall = Math.round((Math.min(100, Math.max(0, 50 + speedDelta * 3)) * .22) + (Math.min(100, Math.max(0, 50 + repeatDelta * 3)) * .18) + (Math.min(100, Math.max(0, 50 + technicalDelta * 2)) * .2) + (Math.min(100, adherence) * .18) + (readinessScore * .12) + (sorenessScore * .1));
  const status = overall >= 75 ? 'Trending up' : overall >= 58 ? 'Building steadily' : 'Needs attention';
  const headline = overall >= 75 ? 'Your outputs are moving in the right direction.' : overall >= 58 ? 'The signal is positive, but consistency is the multiplier.' : 'Protect quality before adding more load.';
  const recovery = values.soreness >= 6 || values.readiness <= 4 ? 'Reduce high-speed volume by 20% and keep one extra recovery block before the next hard session.' : values.soreness >= 4 || values.readiness <= 6 ? 'Keep the plan, but extend warm-up and cap the final high-intensity block if mechanics fade.' : 'You are tolerating the current load well. Progress one variable at a time next week.';
  return {
    overall,
    status,
    headline,
    recovery,
    metrics: [
      { label: '10m acceleration', value: `${speedDelta >= 0 ? '+' : ''}${speedDelta.toFixed(1)}%`, detail: `${values.latestSprint.toFixed(2)}s latest`, positive: speedDelta >= 0 },
      { label: 'Repeat-sprint average', value: `${repeatDelta >= 0 ? '+' : ''}${repeatDelta.toFixed(1)}%`, detail: `${values.latestRepeat.toFixed(2)}s latest`, positive: repeatDelta >= 0 },
      { label: 'Technical execution', value: `${technicalDelta >= 0 ? '+' : ''}${technicalDelta.toFixed(1)}%`, detail: `${values.latestTechnical}% completion`, positive: technicalDelta >= 0 },
      { label: 'Session adherence', value: `${Math.round(adherence)}%`, detail: `${values.sessionsCompleted}/${values.sessionsPlanned} sessions`, positive: adherence >= 80 }
    ]
  };
}

function coachReply(question) {
  const text = question.toLowerCase();
  const plan = generatePlan(currentForm);
  const analysis = analyzeAthleteResults(analyzerState);
  if (text.includes('today') || text.includes('session')) return `Your current week is built around ${plan.form.emphasis.toLowerCase()} for a ${plan.form.position.toLowerCase()}. Keep the session at ${plan.form.duration} minutes and use ${plan.position.priority} as the quality filter. If mechanics fade, cut volume before intent.`;
  if (text.includes('recover') || text.includes('sore') || text.includes('readiness')) return `${analysis.recovery} Tonight, protect an 8–9 hour sleep window, hydrate early, and use an easy 20–30 minute walk if your legs feel heavy.`;
  if (text.includes('fuel') || text.includes('eat') || text.includes('nutrition')) return 'Take a carbohydrate-led meal 2–3 hours before training, then pair 25–40g protein with a generous carbohydrate portion within 60 minutes after. Start with 500ml in the 90 minutes before the session.';
  if (text.includes('progress') || text.includes('score') || text.includes('results')) return `Your current progress score is ${analysis.overall}/100 — ${analysis.status.toLowerCase()}. The clearest next step is to repeat the same tests under similar conditions before changing the programme.`;
  if (text.includes('speed') || text.includes('sprint')) return 'For speed work, take full recovery between exposures. The goal is a cleaner first three metres, not accumulated fatigue. Stop the set when posture or braking quality changes.';
  if (text.includes('plan') || text.includes('week')) return `This week has ${plan.form.days} planned training days, a ${plan.form.matchday.toLowerCase()} matchday context, and a ${plan.form.emphasis.toLowerCase()} bias. Open My week for the full seven-day breakdown.`;
  return 'I can help with your session, recovery, fuel timing, progress score, sprint work, or the full weekly plan. Ask one specific question and I’ll keep the answer practical.';
}

function generatePlan(form) {
  const position = positions[form.position];
  const goal = goalMeta[form.goal];
  const duration = Number(form.duration);
  const matchDay = form.matchday;
  const hasMatch = matchDay !== 'No match this week';
  const matchIndex = { Monday: 0, Tuesday: 1, Wednesday: 2, Thursday: 3, Friday: 4, Saturday: 5, Sunday: 6 };
  const dayIndex = hasMatch ? matchIndex[matchDay] : -1;
  const dayTemplates = [
    {
      title: 'Tissue prep + force qualities',
      focus: 'Strength & tissue capacity',
      intensity: 'RPE 7',
      main: [
        ['A1', 'Rear-foot elevated split squat', '3 × 6 / side', 'Controlled eccentric, drive through the front foot'],
        ['A2', 'Single-leg hip lock + reach', '3 × 5 / side', 'Own pelvis position before the reach'],
        ['B1', 'Nordic hamstring (assisted)', '3 × 4', '4-second lower, partner assist up'],
        ['B2', 'Copenhagen plank + adductor lift', '3 × 20s / side', 'Long spine, breathe behind the brace'],
        ['C', `${position.technical.split(',')[0]} circuit`, '4 × 90s', 'Ball work at 75–80%, scan before every receive']
      ],
      note: `Build the chassis for ${position.priority}. Keep the final rep crisp, never grind.`
    },
    {
      title: 'Acceleration + change of direction',
      focus: 'Speed & multi-directional mechanics',
      intensity: 'RPE 8',
      main: [
        ['A', 'Wall drill → falling start', '3 × 3 / side', 'Shin angle forward, punch the ground'],
        ['B', '10m acceleration + 5m brake', '5 reps', 'Walk-back recovery; stick the last step'],
        ['C', 'Reactive 505 cut', '4 / side', 'Coach points late; lower centre of mass before cut'],
        ['D', 'Ball-carry separation', '5 × 12s', 'Explode past a passive defender, finish action'],
        ['E', 'Dead bug + contralateral reach', '3 × 8 / side', 'Ribs down, slow return']
      ],
      note: 'Quality over volume. Full recovery between high-speed exposures preserves the stimulus.'
    },
    {
      title: 'Regeneration + technical rhythm',
      focus: 'Tactical recovery & ball mastery',
      intensity: 'RPE 3',
      main: [
        ['A', 'Bike or pool flush', '12 min', 'Nasal breathing, conversational pace'],
        ['B', 'Mobility flow', '2 × 6 min', 'Ankle, hip flexor, adductor and T-spine'],
        ['C', 'Two-touch wall sequence', '8 min', 'Alternate feet; receive across the body'],
        ['D', 'Video + scanning prompts', '12 min', `${position.tactical}; 3 clips, 1 cue each`],
        ['E', 'Breathing reset', '4 × 60s', '4-second inhale, 6-second exhale']
      ],
      note: 'Leave the field fresher than you arrived. This is a performance session, not a hidden conditioning day.'
    },
    {
      title: 'Repeat-sprint + tactical intensity',
      focus: 'Match-intensity conditioning',
      intensity: 'RPE 8',
      main: [
        ['A', 'Dynamic mobility + ball pulse', '8 min', 'Open hips, lateral shuffle, quick touches'],
        ['B', 'Repeated sprint set', '2 × 5 × 20m', '20s between reps, 3 min between sets'],
        ['C', '4v4 + floaters', '4 × 3 min', 'Transition on coach call; immediate counterpress'],
        ['D', 'Position action under fatigue', '4 × 45s', `${position.technical}; finish with intent`],
        ['E', 'Pallof press isometric', '3 × 20s / side', 'Resist rotation as heart rate drops']
      ],
      note: 'Aim for repeatable football speed, not a lab sprint. The last block should look like the first.'
    },
    {
      title: 'Primer + set-piece clarity',
      focus: 'Neural primer & tactical sharpness',
      intensity: 'RPE 5',
      main: [
        ['A', 'Low-volume pogo + snap-down', '2 × 12', 'Quiet landings, stiff ankle'],
        ['B', '3 × 10m acceleration', '3 reps', '95% intent, complete recovery'],
        ['C', 'First-touch + finish', '3 × 4 / side', `${position.technical}; one clean action`],
        ['D', 'Set-piece / rest-defence walkthrough', '12 min', `${position.tactical}; communicate early`],
        ['E', 'Hip lock + calf isometric', '2 × 30s / side', 'Finish feeling better than you started']
      ],
      note: 'This is a primer, not a test. Keep volume low and intent high so the weekend output is available.'
    },
    {
      title: hasMatch ? `${matchDay} matchday` : 'Football exposure day',
      focus: hasMatch ? 'Competition & live decision-making' : 'Small-sided football conditioning',
      intensity: hasMatch ? 'RPE 9' : 'RPE 7',
      main: hasMatch ? [
        ['A', 'Match activation', '18 min', 'Raise temperature, mobilise, 3 progressive accelerations'],
        ['B', 'Competitive minutes', '60–90 min', `${position.descriptor}; protect your first action`],
        ['C', 'Immediate post-match', '10 min', 'Walk, hydrate, carbohydrate + protein within 45 min'],
        ['D', 'Downregulation', '6 min', 'Long exhale, calves/hip flexors, legs up']
      ] : [
        ['A', 'Dynamic activation', '12 min', 'Movement prep, deceleration and reaction games'],
        ['B', '5v5 + transition gates', '5 × 4 min', 'High intent; 2 min recovery between blocks'],
        ['C', 'Finishing / distribution', '3 × 5 min', `${position.technical}; finish each action`],
        ['D', 'Regeneration', '8 min', 'Walk, breathe, mobility and refuel']
      ],
      note: hasMatch ? 'Compete with clarity. The plan is won by the quality of your first five actions and your response after errors.' : 'Use this as a robust football day, not an excuse to accumulate junk volume.'
    },
    {
      title: 'Reset + next-week readiness',
      focus: 'Recovery & readiness audit',
      intensity: 'RPE 2',
      main: [
        ['A', 'Walk / easy cycle', '20–30 min', 'Keep it easy enough to nose-breathe'],
        ['B', 'Mobility & tissue care', '12 min', 'Ankle rocks, 90/90, adductor rocks, T-spine'],
        ['C', 'Readiness check-in', '5 min', 'Sleep, soreness, mood, energy, next-session note'],
        ['D', 'Imagery + clips', '10 min', `Review one cue for ${position.tactical}`]
      ],
      note: 'Recovery is a training session with a lower heart rate. Set up Monday before Monday arrives.'
    }
  ];

  const templateIndexes = [0, 1, 2, 3, 4, 4, 6];
  const days = baseDays.map((day, i) => {
    let template = dayTemplates[templateIndexes[i]];
    if (dayIndex === i) template = dayTemplates[5];
    if (form.goal === 'Post-Season Recovery' && i !== dayIndex) template = i === 1 || i === 3 ? dayTemplates[2] : dayTemplates[6];
    if (form.goal === 'Speed & Agility' && i === 0) template = dayTemplates[1];
    if (form.goal === 'Strength & Power' && i === 0) template = dayTemplates[0];
    if (form.goal === 'Injury Comeback' && i !== dayIndex && i !== 5) template = i % 2 === 0 ? dayTemplates[2] : { ...dayTemplates[0], intensity: 'RPE 5', note: 'Use a pain-free range and stop one rep before compensation. Progress only when mechanics stay clean.' };
    const isRest = form.goal === 'Post-Season Recovery' ? i === 4 || i === 6 : (i === 6 || (Number(form.days) <= 4 && [2, 4].includes(i)));
    return { ...day, ...template, isRest, duration: isRest ? 'Recovery' : `${duration} min` };
  });

  return {
    position,
    goal,
    days,
    matchContext: hasMatch ? `${matchDay} matchday / ${form.days} planned training days` : `${form.days} planned training days / no match load`,
    load: form.goal === 'Post-Season Recovery' ? 'Low' : form.goal === 'Injury Comeback' ? 'Modulated' : 'Moderate-high',
    optionCue: `${form.foot.toLowerCase()}-foot actions, ${form.environment.toLowerCase()}, ${form.emphasis.toLowerCase()} bias`,
    sessionCount: Number(form.days),
    form
  };
}

function header() {
  return `<header class="topbar"><div class="brand"><div class="brand-mark"><span></span><span></span><span></span></div><div class="brand-copy"><strong>pitch<span>lab</span></strong><small>performance planning</small></div></div><nav class="nav-links"><a href="#planner" class="active">Planner</a><a href="#week">My week</a><a href="#analyzer">AI analyst</a><a href="#principles">Principles</a></nav><div class="header-actions"><span class="status-dot"></span><span class="header-status">Coach mode</span><button class="menu-button" aria-label="Open menu">${icon('menu', 18)}</button></div></header>`;
}

function plannerPanel() {
  return `<section class="planner-card" id="planner"><div class="section-kicker"><span class="eyebrow-dot"></span> Build your week</div><h1>Train with <em>intent.</em></h1><p class="hero-copy">A football-specific microcycle shaped around your position, your match calendar and the quality you need next.</p><div class="form-grid">${selectField('position', 'Player position', currentForm.position, Object.keys(positions))}${selectField('fitness', 'Current fitness', currentForm.fitness, ['Beginner', 'Intermediate', 'Elite / Pro'])}${selectField('goal', 'Primary goal', currentForm.goal, Object.keys(goalMeta))}${selectField('days', 'Training days', currentForm.days, ['3', '4', '5', '6'], 'Excludes matchday')}${selectField('matchday', 'Matchday', currentForm.matchday, ['Saturday', 'Sunday', 'Wednesday', 'No match this week'])}${selectField('duration', 'Session duration', currentForm.duration, ['45', '60', '75', '90'], 'Main session time')}<div class="options-kicker"><span>Player options</span><small>Fine-tune the prescription</small></div>${selectField('foot', 'Preferred foot', currentForm.foot, ['Right', 'Left', 'Both / balanced'])}${selectField('environment', 'Training environment', currentForm.environment, ['Full gym + pitch', 'Pitch + minimal equipment', 'Home / bodyweight'])}${selectField('emphasis', 'Session emphasis', currentForm.emphasis, ['Speed & agility', 'Technical sharpness', 'Strength & power', 'Recovery quality'])}</div><div class="form-footer"><div class="confidence"><span class="confidence-ring">${icon('check', 16)}</span><span><strong>Ready to personalise</strong><small>Built from football performance principles</small></span></div><button class="primary-button" id="generate-plan">Generate my week ${icon('arrow', 18)}</button></div></section>`;
}

function overview(plan) {
  const p = plan.position;
  const form = plan.form;
  const goal = plan.goal;
  return `<section class="overview-section" id="week"><div class="section-heading"><div><span class="eyebrow">01 / Weekly brief</span><h2>Your week, <em>mapped.</em></h2></div><span class="plan-id">PLAN / ${String(planVersion).padStart(2, '0')}</span></div><div class="overview-grid"><div class="brief-card"><div class="brief-top"><span class="tag tag-lime">${goal.tag}</span><span class="muted-label">${plan.matchContext}</span></div><h3>${form.position} <span>×</span> ${goal.tag.toLowerCase()}</h3><p>${goal.tone} For a ${form.fitness.toLowerCase()} ${p.descriptor}, the week prioritises <strong>${p.priority}</strong> while keeping technical rhythm and tactical clarity present every day.</p><div class="option-summary"><span>Configured for</span><strong>${plan.optionCue}</strong></div><div class="metric-row"><div class="metric"><span class="metric-value">${form.days}</span><span class="metric-label">training days</span></div><div class="metric"><span class="metric-value">${form.duration}<small>m</small></span><span class="metric-label">session target</span></div><div class="metric"><span class="metric-value">${plan.load}</span><span class="metric-label">weekly load</span></div></div></div><div class="priority-card"><div class="priority-head"><span>Coach's lens</span>${icon('bolt', 17)}</div><div class="priority-main"><span class="priority-number">${p.code}</span><div><h4>Make the next action cleaner.</h4><p>Every session has a football consequence: arrive earlier, brake better, or execute with less noise.</p></div></div><div class="strength-list">${p.strengths.map((strength, i) => `<span><i>${String(i + 1).padStart(2, '0')}</i>${strength}</span>`).join('')}</div></div></div></section>`;
}

function analyzerSection() {
  const analysis = analyzeAthleteResults(analyzerState);
  return `<section class="analyzer-section" id="analyzer"><div class="section-heading"><div><span class="eyebrow">01.5 / Athlete intelligence</span><h2>Measure the <em>signal.</em></h2></div><div class="ai-badge">${icon('bolt', 14)} Private AI coach logic</div></div><div class="analyzer-grid"><div class="results-entry"><div class="entry-head"><div><span class="entry-kicker">Add your results</span><h3>Baseline → latest</h3></div><span class="entry-note">Use comparable tests, same surface and similar conditions.</span></div><div class="result-groups"><div class="result-group"><span class="group-title">Speed & repeatability</span><div class="result-row">${resultField('baselineSprint', '10m sprint / baseline', analyzerState.baselineSprint, 'sec', '0.01')}${resultField('latestSprint', '10m sprint / latest', analyzerState.latestSprint, 'sec', '0.01')}</div><div class="result-row">${resultField('baselineRepeat', 'Repeat-sprint avg / baseline', analyzerState.baselineRepeat, 'sec', '0.01')}${resultField('latestRepeat', 'Repeat-sprint avg / latest', analyzerState.latestRepeat, 'sec', '0.01')}</div></div><div class="result-group"><span class="group-title">Football output</span><div class="result-row">${resultField('baselineTechnical', 'Technical execution / baseline', analyzerState.baselineTechnical, '%')}${resultField('latestTechnical', 'Technical execution / latest', analyzerState.latestTechnical, '%')}</div><div class="result-row">${resultField('sessionsPlanned', 'Sessions planned', analyzerState.sessionsPlanned, 'sessions')}${resultField('sessionsCompleted', 'Sessions completed', analyzerState.sessionsCompleted, 'sessions')}</div></div><div class="result-group compact"><span class="group-title">How you feel today</span><div class="result-row">${resultField('readiness', 'Readiness', analyzerState.readiness, '/ 10')}${resultField('soreness', 'Soreness', analyzerState.soreness, '/ 10')}</div></div></div><button class="analyze-button" id="analyze-results">Run AI analysis ${icon('arrow', 18)}</button></div><div class="analysis-output"><div class="analysis-top"><div><span class="entry-kicker">AI readout</span><h3>${analysis.headline}</h3></div><div class="score-orb"><strong>${analysis.overall}</strong><span>progress<br />score</span></div></div><div class="analysis-status"><span class="status-pip"></span><strong>${analysis.status}</strong><span>Based on your latest submitted block</span></div><div class="analysis-metrics">${analysis.metrics.map(metric => `<div class="analysis-metric"><div class="metric-line"><span>${metric.label}</span><b class="${metric.positive ? 'up' : 'down'}">${metric.value}</b></div><small>${metric.detail}</small><div class="metric-bar"><i class="${metric.positive ? 'up' : 'down'}" style="width:${Math.min(100, Math.max(12, Math.abs(parseFloat(metric.value)) * 3 + 40))}%"></i></div></div>`).join('')}</div><div class="ai-recommendation"><span class="recommendation-icon">${icon('activity', 16)}</span><p><strong>Next-week recommendation</strong>${analysis.recovery}</p></div></div></div></section>`;
}

function sessionCard(session, index) {
  const active = activeDay === index ? ' active' : '';
  const isRest = session.isRest;
  return `<article class="session-card${active}" data-day-index="${index}"><div class="session-index"><span>${String(index + 1).padStart(2, '0')}</span><b>${session.short}</b></div><div class="session-body"><div class="session-top"><div><span class="session-type ${session.color}">${session.type}</span><h3>${session.title}</h3></div><div class="session-meta"><span>${icon('clock', 15)} ${session.duration}</span><span>${icon('activity', 15)} ${session.intensity}</span></div></div><div class="session-focus"><span class="focus-label">Focus</span><strong>${session.focus}</strong><span class="focus-rule"></span><span class="session-state">${isRest ? 'Regeneration priority' : 'Main session'}</span></div><div class="session-detail"><div class="warmup"><span class="detail-label">Warm-up / activation</span><p>${isRest ? '10 min easy movement: ankle rocks, hip switches, adductor rocks, T-spine rotations, then 2 × 30s breathing reset.' : '8 min dynamic prep: jog → lateral shuffle → open/close gate → ankle pogo → 2 × 10m progressive accelerations.'}</p></div><div class="drill-list"><span class="detail-label">Main work</span>${session.main.map(([code, name, reps, cue]) => `<div class="drill"><span class="drill-code">${code}</span><strong>${name}</strong><span class="drill-reps">${reps}</span><span class="drill-cue">${cue}</span></div>`).join('')}</div><div class="cooldown"><span class="detail-label">Cool-down / regeneration</span><p>${session.note}</p></div></div></div><button class="session-toggle" aria-label="Toggle session details">${icon('chevron', 17)}</button></article>`;
}

function weekSchedule(plan) {
  return `<section class="schedule-section"><div class="section-heading schedule-heading"><div><span class="eyebrow">02 / Microcycle</span><h2>Seven days of <em>purpose.</em></h2></div><div class="legend"><span><i class="legend-dot lime"></i> output</span><span><i class="legend-dot sky"></i> recovery</span></div></div><div class="schedule-tabs">${plan.days.map((day, i) => `<button class="day-tab ${i === activeDay ? 'active' : ''}" data-day-tab="${i}"><span>${day.short}</span><strong>${String(i + 1).padStart(2, '0')}</strong></button>`).join('')}</div><div class="sessions">${plan.days.map((session, i) => sessionCard(session, i)).join('')}</div></section>`;
}

function fuelSection(plan) {
  const heavy = plan.form.goal === 'Post-Season Recovery' ? 'recovery' : 'high-output';
  return `<section class="fuel-section" id="principles"><div class="section-heading"><div><span class="eyebrow">03 / Recovery system</span><h2>Refuel the <em>work.</em></h2></div><p class="heading-note">Performance is the work you can repeat. Build the habits that let you return with intent.</p></div><div class="fuel-grid"><div class="fuel-card dark"><div class="fuel-icon">${icon('drop', 20)}</div><span class="fuel-kicker">Hydration</span><h3>Stay ahead of thirst.</h3><p>Start with 500ml in the 90 minutes before training. Add 400–800ml per hour on ${heavy} days, with electrolytes when sweat or heat is high.</p><div class="fuel-rule"><span></span><span></span><span></span><span></span></div><small>Target: pale straw urine + a clear head</small></div><div class="fuel-card orange"><div class="fuel-icon">${icon('bolt', 20)}</div><span class="fuel-kicker">Fuel timing</span><h3>Put energy near the work.</h3><p>Take a carbohydrate-led meal 2–3 hours before. After the session, pair 25–40g protein with a generous carbohydrate portion within 60 minutes.</p><div class="fuel-stat"><strong>25–40g</strong><span>post-session protein</span></div></div><div class="fuel-card sky"><div class="fuel-icon">${icon('moon', 20)}</div><span class="fuel-kicker">Sleep + reset</span><h3>Protect the next session.</h3><p>Keep a consistent 8–9 hour sleep window. On lower-load days, use a 20–30 minute walk, legs-up breathing and a quick readiness audit.</p><div class="sleep-line"><span>sleep window</span><strong>8–9 hrs</strong></div></div></div><div class="coach-note"><span class="note-mark">“</span><p><strong>One non-negotiable for this week:</strong> ${plan.position.priority}. If the quality drops, reduce volume before you reduce intent.</p><span class="note-signature">— pitchlab coaching system</span></div></section>`;
}

function chatbot() {
  return `<div class="coach-chat ${chatOpen ? 'open' : ''}"><button class="chat-launcher" id="chat-launcher" aria-label="Open AI coach chat"><span class="chat-pulse"></span>${icon('activity', 19)}<b>Coach AI</b></button><div class="chat-panel" aria-live="polite"><div class="chat-head"><div><span class="chat-eyebrow">PitchLab / live coach</span><strong>Ask the analyst</strong></div><button class="chat-close" id="chat-close" aria-label="Close chat">${icon('close', 16)}</button></div><div class="chat-messages">${chatMessages.map(message => `<div class="chat-message ${message.role}"><span class="message-avatar">${message.role === 'coach' ? 'PL' : 'YOU'}</span><p>${message.text}</p></div>`).join('')}</div><div class="chat-suggestions"><button data-chat-suggestion="What should I do today?">Today’s session</button><button data-chat-suggestion="How is my progress?">Read my progress</button><button data-chat-suggestion="How should I fuel?">Fuel timing</button></div><form class="chat-form" id="chat-form"><input id="chat-input" autocomplete="off" placeholder="Ask your coach..." /><button class="voice-input ${isListening ? 'listening' : ''}" id="voice-input" type="button" aria-label="Use voice input" title="Use voice input">${icon('mic', 17)}</button><button type="submit" aria-label="Send message">${icon('arrow', 17)}</button></form><small class="chat-disclaimer">Contextual guidance from your current PitchLab plan. Not medical advice.</small></div></div>`;
}

function render() {
  const plan = generatePlan(currentForm);
  document.querySelector('#app').innerHTML = `${header()}<main><section class="hero-layout"><div class="hero-intro"><div class="hero-ornament">${icon('activity', 20)} <span>Football performance / 2026</span></div><p class="hero-index">01 <span>—</span> the weekly edge</p><h2>Less noise.<br /><em>More transfer.</em></h2><p class="hero-subcopy">A personalised operating system for players who want every sprint, cut, touch and recovery choice to matter.</p><div class="hero-statline"><span><strong>07</strong><small>days mapped</small></span><span><strong>01</strong><small>clear focus</small></span><span><strong>∞</strong><small>repeatability</small></span></div></div>${plannerPanel()}</section>${overview(plan)}${analyzerSection()}${weekSchedule(plan)}${fuelSection(plan)}</main><footer class="footer"><div class="brand mini"><div class="brand-mark"><span></span><span></span><span></span></div><strong>pitch<span>lab</span></strong></div><span>Designed for the detail between the lines.</span><span>v1.0 / coach mode</span></footer>${chatbot()}<div class="toast" role="status" aria-live="polite"></div>`;
  bindEvents();
}

function bindEvents() {
  document.querySelectorAll('[data-field]').forEach(select => select.addEventListener('change', event => {
    currentForm[event.target.dataset.field] = event.target.value;
  }));
  document.querySelectorAll('[data-result]').forEach(input => input.addEventListener('input', event => {
    analyzerState[event.target.dataset.result] = event.target.value;
  }));
  document.querySelector('#generate-plan').addEventListener('click', () => {
    planVersion += 1;
    activeDay = 0;
    render();
    const toast = document.querySelector('.toast');
    toast.textContent = 'Your week is mapped. Quality first.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2600);
    document.querySelector('#week').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  document.querySelector('#analyze-results').addEventListener('click', () => {
    render();
    const toast = document.querySelector('.toast');
    toast.textContent = 'AI readout updated from your latest results.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2600);
    document.querySelector('#analyzer').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  document.querySelector('#chat-launcher').addEventListener('click', () => {
    chatOpen = !chatOpen;
    render();
    if (chatOpen) document.querySelector('#chat-input')?.focus();
  });
  document.querySelector('#chat-close').addEventListener('click', () => {
    chatOpen = false;
    render();
  });
  document.querySelectorAll('[data-chat-suggestion]').forEach(button => button.addEventListener('click', () => {
    submitChat(button.dataset.chatSuggestion);
  }));
  document.querySelector('#chat-form').addEventListener('submit', event => {
    event.preventDefault();
    const input = document.querySelector('#chat-input');
    submitChat(input.value);
  });
  document.querySelector('#voice-input').addEventListener('click', startVoiceInput);
  document.querySelectorAll('[data-day-tab]').forEach(tab => tab.addEventListener('click', () => {
    activeDay = Number(tab.dataset.dayTab);
    document.querySelectorAll('.day-tab').forEach(item => item.classList.remove('active'));
    tab.classList.add('active');
    document.querySelectorAll('.session-card').forEach((card, index) => card.classList.toggle('active', index === activeDay));
    document.querySelectorAll('.session-card')[activeDay]?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }));
  document.querySelectorAll('.session-toggle').forEach(button => button.addEventListener('click', () => {
    const card = button.closest('.session-card');
    card.classList.toggle('collapsed');
  }));
  document.querySelector('.menu-button').addEventListener('click', () => {
    document.querySelector('.nav-links').classList.toggle('open');
  });
}

function submitChat(question) {
  const cleanQuestion = question.trim();
  if (!cleanQuestion) return;
  chatMessages.push({ role: 'user', text: cleanQuestion });
  chatMessages.push({ role: 'coach', text: coachReply(cleanQuestion) });
  chatOpen = true;
  render();
  requestAnimationFrame(() => {
    const messages = document.querySelector('.chat-messages');
    if (messages) messages.scrollTop = messages.scrollHeight;
  });
}

function startVoiceInput() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    const toast = document.querySelector('.toast');
    toast.textContent = 'Voice input is not supported in this browser.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2600);
    return;
  }
  if (isListening) return;
  const recognition = new SpeechRecognition();
  recognition.lang = 'en-US';
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;
  isListening = true;
  document.querySelector('#voice-input')?.classList.add('listening');
  recognition.onresult = event => {
    const input = document.querySelector('#chat-input');
    if (input) input.value = event.results[0][0].transcript;
  };
  recognition.onerror = () => {
    const toast = document.querySelector('.toast');
    toast.textContent = 'I could not hear that. Try again or type your question.';
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2600);
  };
  recognition.onend = () => {
    isListening = false;
    document.querySelector('#voice-input')?.classList.remove('listening');
  };
  recognition.start();
}

render();
